public class MediumCargo extends Cargo {
    public MediumCargo(int length, int width) {
        super(length, width);
        contents = "MEDIUM";
    }
}

