public enum RatingType {
    LOW,
    MEDIUM,
    HIGH;
}
